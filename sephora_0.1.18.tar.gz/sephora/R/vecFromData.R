
#' Get numeric vector from datacube
#' 
#' Extract a numeric vector from a datacube 
#' 
#' @param   product character indicating whether \code{data} comes from \code{MOD13Q1} (default) time series satellite
#'                  imagery or from an \code{independent} product.
#' @param      data a matrix containing measurements of subsets (polygons) of a datacube. \code{nrow} is equal to the number of pixels in the polygon and \code{ncol} is equal 
#'                  to the amount of images in the time series.
#' @param    numRow numeric, number of row to extract from \code{data}.
#' @param lenPeriod numeric, number of observations per period. Default, 23.
#' 
#' 
#' @export
#' 
#' @details When \code{product=MOD13Q1}, this function assumes that \code{data} contains observations from
#' 01-01-2000. Although the first available MOD13Q1 product dates back to 18-02-2000,
#' this function uses \code{\link[sephora]{fill_initialgap_MOD13Q1}} to impute
#' the first three missing images from 2000.
#' 
#' @seealso \code{\link[geoTS]{raster_intersect_sp}}, \code{\link{vecToMatrix}}, 
#' \code{\link{fill_initialgap_MOD13Q1}}.
#' 
#' @return A list with two components:
#' \item{mat}{extracted vector in matricial form}
#' \item{vec}{extracted vector}
#' 
vecFromData <- function(product=c("MOD13Q1", "independent"), data, 
                        numRow, lenPeriod=23){
  data_vec <- as.numeric(data[numRow,])
  data_mat <- vecToMatrix(x=data_vec, lenPeriod=lenPeriod)
  
  product <- match.arg(product)
  
  if( product == "MOD13Q1" ){
    data_mat[1,1:3] <- fill_initialgap_MOD13Q1(m=data_mat)
  }
  
list(mat=data_mat, vec=c(t(data_mat)))
}
