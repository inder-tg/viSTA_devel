# plotMS <- function(x,...) UseMethod("plotMS", x)

#' Plot method for \code{phenopar} function
#'
#' This function displays the hierarchical clustering output in the form of a
#' multidimensional scaling (ms) plot
#'
#' @param            x  a \code{phenopar} object.
#' @param    startYear  integer, time series initial year
#' @param      endYear  integer, time series final year
#' @param   pointShape  \code{shape} parameter used in \code{geom_point}. Default 16.
#' @param    pointSize  \code{size} parameter used in \code{geom_point}. Default 2.
#' @param  pointStroke  \code{stroke} parameter used in \code{geom_point}. Default 3.
#' @param textFontface  \code{fontface} parameter used in \code{geom_text}. Default 2.
#' @param     textSize  \code{size} parameters used in \code{geom_text}. Default 5.
#' @param   text_hjust  \code{hjust} parameter used in \code{geom_text}. Default 0.5.
#' @param   text_vjust  \code{vjust} parameter used in \code{geom_text}. Default -0.5.
#'
#' @rdname plotMS
#' @export
#'
#' @importFrom ggplot2 ggplot
#' @importFrom ggplot2 ggplot_build
#' @importFrom ggplot2 geom_point
#' @importFrom ggplot2 aes
#' @importFrom ggnewscale new_scale_color
#' @importFrom stats cmdscale
#' @importFrom nlme lme
#' @importFrom MASS mvrnorm
#'
#' @return No value is returned
#' 
#' @seealso \code{\link[ggplot2]{ggplot}}
#'
plotMS <- function(x, startYear=2000, endYear=2021, pointShape=16, pointSize=2, 
                   pointStroke=3, textFontface=2, textSize=5, text_hjust=0.5, 
                   text_vjust=-0.5){
  
  if(!inherits(x, "phenopar")){
    stop("x must be of class phenopar")
  }
  
  out_aux <- tsPlot(x=x$x, startYear=startYear, endYear=endYear,
                    frequency=x$freq, xLab="", yLab="")
  
  COLORS <- unique( ggplot_build(out_aux)$data[1][[1]]$colour )
  
  cmd_distmat <- cmdscale(x$clustering@distmat)
  cmd_distmat <- as.data.frame(cmd_distmat)
  
  cmd_distmat$cluster <- as.factor(x$clustering@cluster)
  
  TEMP <- get_metadata_years(x=x$x, startYear = startYear, endYear = endYear)
  AUX <- paste0("'", TEMP$xLabels)
  
  # cmd_distmat$years <- c("'00","'01","'02","'03","'04","'05","'06",
  #                        "'07","'08","'09","'10","'11","'12","'13",
  #                        "'14","'15","'16", "'17", "'18", "'19", "'20",
  #                        "'21")
  
  cmd_distmat$years <- AUX
  
  names(cmd_distmat) <- c('x','y','cluster','years')
  
  df <- data.frame(x=cmd_distmat$x, y=cmd_distmat$y,
                   cluster=cmd_distmat$cluster,
                   years=cmd_distmat$years)
  
  ggplot(data=df,
         aes(x=df$x,y=df$y, group=df$years)) +
    geom_point(aes(colour=df$cluster), shape=pointShape, size=pointSize,
               stroke=pointStroke) +
    ggplot2::xlab("x") +
    ggplot2::ylab("y") +
    new_scale_color() +
    ggplot2::geom_text(aes(label=df$years, col=df$years),
                       fontface=textFontface, size=textSize,
                       hjust=text_hjust, vjust=text_vjust,
                       show.legend=FALSE) +
    ggplot2::scale_color_manual(values=COLORS)
  
}
