#' Phenological parameters estimation in mass
#' 
#' Estimation of phenological parameters from a set of numeric vectors stored in a RData file. 
#' Output is saved as a RData file at the destination specified by \code{dirToSave}
#'
#' @param               path character with full path of RData file containing numeric vectors to analyze.
#' @param            product character specifying whether dataset is the \code{MOD13Q1} product (default) or 
#'                           a different one (\code{independent}).
#' @param               data matrix with dataset to analyze. Pertinent when \code{product="independent"}.                           
#' @param          frequency integer giving number of observations per season. Default, 23.
#' @param             method character. Should \code{OLS} or \code{WLS} be used for smoothing each
#'                           numeric vector in RData file specified in \code{path}?
#' @param              sigma numeric vector of length equal to \code{frequency}. Each entry gives the 
#'                           standard deviation of observations acquired at same day of the year. 
#'                           Pertinent when \code{method=WLS}.
#' @param            numFreq integer specifying number of frequencies to use in harmonic regression
#'                           model.
#' @param              delta numeric. Default, 0. When regression problem is ill-posed, this
#'                           parameter allows a simple regularization.
#' @param           distance character indicating what distance to use in hierarchical clustering.
#'                           All distances in \code{\link[dtwclust]{tsclust}} are allowed.
#' @param            samples integer with number of samples to draw from smoothed version of numeric
#'                           vector to analyze. Used exclusively in Functional Principal Components Analysis (FPCA)-based
#'                           regression.
#' @param              basis list giving numeric basis used in FPCA-based regression. See details.
#' @param               corr Default \code{NULL}. Object defining correlation structure, can be
#'                           numeric vector, matrix or function.
#' @param                  k integer, number of principal components used in FPCA-based regression.
#' @param              trace logical. If \code{TRUE}, progress on the hierarchical clustering
#'                           is printed on console. Default, \code{FALSE}.
#' @param           numCores integer. How many processing cores can be used?
#' @param          dirToSave character. In which directory to save analysis results?
#' @param reportFileBaseName character. What base name should be given to a progress report file? 
#'                           Default, \code{phenopar_progress}.
#' @param outputFileBaseName character. What base name should be given to the output file? 
#'                           Default, \code{polygon}.                            
#'
#' @export
#'
#' @importFrom doParallel registerDoParallel
#' @importFrom foreach foreach
#' @importFrom foreach %dopar%
#' @importFrom parallel stopCluster
#' @importFrom utils globalVariables
#' @importFrom dtwclust tsclust
#' @importFrom geoTS haRmonics
#' @importFrom geoTS hetervar
#' @importFrom eBsc drbasis
#' @importFrom rootSolve uniroot.all
#'
#' @return At the location specified by \code{dirToSave}, a file containing a matrix
#' with \code{nrow} equal to the number of numeric vectors analyzed and 6 columns, is saved. 
#' The name of this file is:
#' 
#' \code{paste0(tools::file_path_sans_ext(basename(path)), "_phenoparams.RData")}.
#'
#' @seealso \code{phenopar}, \code{\link[dtwclust]{tsclust}}.
#'
phenopar_polygon <- function(path, product=c("MOD13Q1", "independent"), data,
                             frequency=23, method=c("OLS", "WLS"), sigma=NULL,
                             numFreq, delta=0, distance, samples, basis, corr=NULL,
                             k, trace=FALSE, numCores=20, dirToSave,
                             reportFileBaseName="phenopar_progress",
                             outputFileBaseName="polygon"){
  
  if(missing(dirToSave)){
    stop('dirToSave must be provided')
  }
  
  product <- match.arg(product)
  
  method <- match.arg(method)
  
  if(product == "MOD13Q1"){
    if(missing(path)){
      stop('path must be provided')
    }
    
    data <- LoadToEnvironment(RData=path)$poly[[1]] * 1e-4
    
  }
  
  output <- phenopar_polygon_auxiliar(data=data, product=product, frequency=frequency, method=method,
                                      sigma=sigma, numFreq=numFreq, delta=delta, distance=distance, 
                                      samples=samples, basis=basis, corr=corr, k=k, trace=trace,
                                      numCores=numCores, dirToSave=dirToSave, reportFileBaseName=reportFileBaseName)
  
  
  save(output, file = paste0(dirToSave, "/",
                             ifelse( !missing(path), 
                                     tools::file_path_sans_ext(basename(path)), 
                                     outputFileBaseName ),
                             "_phenoparams.RData"))
  
}
