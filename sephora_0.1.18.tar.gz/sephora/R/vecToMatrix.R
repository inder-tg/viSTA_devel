#' Transfer numeric vector to a matrix
#' 
#' Auxiliary function to gather data from a satellite imagery time series.
#' 
#' @param         x a numeric vector whose length must be a multiple of \code{lenPeriod}
#' @param lenPeriod a numeric, number of observations per period
#' 
#' @export
#' 
#' @details When used on the MOD13Q1 distributed with this package, this function 
#' assumes that \code{x} contains observations from 01-01-2000. 
#' 
#' @return A matrix with \code{nrow} equal to \code{length(x)/lenPeriod} and
#' \code{ncol} equal to \code{lenPeriod}.
#' 
#' @seealso \code{\link[sephora]{vecFromData}}, \code{\link[sephora]{fill_initialgap_MOD13Q1}}
#' 
vecToMatrix <- function(x, lenPeriod=23){
  
  if(length(x) %% lenPeriod !=0){
    stop("Length of 'x' must be a multiple of 'lenPeriod'")
  }
  
  output <- matrix(nrow=length(x)/lenPeriod, ncol=lenPeriod)
  
  for(i in seq_len(nrow(output))){
    output[i,] <- x[((i-1) * lenPeriod + 1):(i * lenPeriod)]
  }

output
}
