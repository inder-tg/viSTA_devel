# plotPrimes <- function(x,...) UseMethod("plotPrimes", x)

#' Plot method for \code{phenopar} function
#'
#' This function returns a grid with plots of an fpca estimated curve and its first, second,
#' third and fourth derivatives
#'
#' @param      x         a \code{phenopar} object
#' @param    ...         additional plot parameters
#'
#' @rdname plotPrimes
#' @export
#'
#' @importFrom stats cmdscale
#' @importFrom dplyr '%>%'
#'
#' @return No value is returned
#'
#' @seealso \code{\link{phenopar}}
#'
plotPrimes <- function(x, ...){
  
  fec_tipo <- cbind(as.vector(x$phenoparams), names(x$phenoparams))%>%as.data.frame()
  names(fec_tipo) <- c("Date", "Type")
  param_list <- list(params=fec_tipo, number_params=x$phenoparams)
  
  fechas <- c()
  tipos <- c()
  if(is.factor(param_list$params$Date)) {
    fechas <- as.vector(param_list$params$Date)
    tipos <- as.vector(param_list$params$Type)
  } else {
    fechas <- param_list$params$Date
    tipos <- param_list$params$Type
  }
  
  graphics::par(mfrow=c(5,1))
  yRan <- range(x$m_aug_smooth)
  
  graphics::par(mar=c(1.5,4.5,0.5,1))
  plot(x$fpca_fun_0der(seq(1,365,length=365)), col="red", type="l", lwd=4,
       ylab="NDVI", ylim=yRan, xaxt="n", cex.lab=1.25, font.lab=4)
  # axis(side=1, at=DAYS_AT_YEAR, labels=c(MONTHS, ""))
  graphics::abline(h=0, lty=3, col="blue")
  graphics::abline(v=fechas, col=colores, lwd=4)
  
  yRan <- range(x$fpca_fun_1der(seq(1,365,length=365)))
  yRan[1] <- yRan[1]-0.00025
  yRan[2] <- yRan[2]+0.00025
  graphics::par(mar=c(1.5,4.5,0,1))
  plot(x$fpca_fun_1der(seq(1, 365, length=365)), ylim=yRan,
       # ylab="NDVI'",
       ylab=expression(bold('NDVI'^'(1)')),
       xaxt="n", lwd=4, col="blue", cex.lab=1.25, font.lab=4)
  graphics::abline(h=0, lty=3, col="blue")
  graphics::abline(v=fechas, col=colores, lwd=4)
  
  yRan <- range(x$fpca_fun_2der(seq(1,365,length=365)))
  yRan[1] <- yRan[1]-0.0005
  yRan[2] <- yRan[2]+0.0005
  graphics::par(mar=c(1.5,4.5,0,1))
  plot(x$fpca_fun_2der(seq(1, 365, length=365)), ylim=yRan,
       # ylab="NDVI''",
       ylab=expression(bold('NDVI'^'(2)')),
       xaxt="n", lwd=4, col="magenta", cex.lab=1.25, font.lab=4)
  graphics::abline(h=0, lty=3, col="blue")
  graphics::abline(v=fechas, col=colores, lwd=4)
  
  yRan <- range(x$fpca_fun_3der(t=seq(1,365,length=365)))
  graphics::par(mar=c(1.5,4.5,0.5,1))
  plot(x$fpca_fun_3der(t=seq(1, 365, length=365)), ylim=yRan,
       ylab=expression(bold('NDVI'^'(3)')),
       xaxt="n", lwd=4, col="#872657", cex.lab=1.25, cex.axis=1.25, font.lab=4)
  graphics::abline(h=0, lty=3, col="blue")
  graphics::abline(v=fechas, col=colores, lwd=4)
  
  yRan <- range(x$fpca_fun_4der(t=seq(1,365,length=365)))
  graphics::par(mar=c(2,4.5,0,1))
  plot(x$fpca_fun_4der(t=seq(1, 365, length=365)), ylim=yRan,
       ylab=expression(bold('NDVI'^'(4)')),
       xaxt="n", lwd=4, col="#DC143C", cex.lab=1.25, cex.axis=1.25, font.lab=4)
  graphics::axis(side=1, at=DAYS_AT_YEAR, labels=c(MONTHS, ""))
  graphics::abline(h=0, lty=3, col="blue")
  graphics::abline(v=fechas, col=colores, lwd=4)
}
